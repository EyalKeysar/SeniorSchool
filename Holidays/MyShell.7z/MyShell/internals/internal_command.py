

class InternalCommand():
    def execute(self, arg):
        raise NotImplementedError("execute method not implemented")