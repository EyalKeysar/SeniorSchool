def handle_stdout(redirect, stdout):
    print(stdout)
    
    return stdout