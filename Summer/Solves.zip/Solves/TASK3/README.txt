To Run client on cli run the html_sql_client, to run a tkinter GUI, run the GUI file.

injection instructions on inject.txt