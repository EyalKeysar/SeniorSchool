__author__ = "Eyal Keysar"

SERVER_PORT = 1333
SERVER_IP = "127.1.2.3"